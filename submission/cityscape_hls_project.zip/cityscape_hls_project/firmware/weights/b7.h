//Numpy array shape [36]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 36

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
bias7_t b7[36];
#else
bias7_t b7[36] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

#endif

#endif
