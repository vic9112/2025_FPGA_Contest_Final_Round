//Numpy array shape [36]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 36

#ifndef B53_H_
#define B53_H_

#ifndef __SYNTHESIS__
bias53_t b53[36];
#else
bias53_t b53[36] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

#endif

#endif
