//Numpy array shape [60]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 60

#ifndef B31_H_
#define B31_H_

#ifndef __SYNTHESIS__
bias31_t b31[60];
#else
bias31_t b31[60] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

#endif

#endif
