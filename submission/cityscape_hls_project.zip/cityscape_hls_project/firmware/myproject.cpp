#include <iostream>

#include "myproject.h"
#include "parameters.h"


void myproject(
    hls::stream<input_t> &input_1,
    hls::stream<result_t> &layer57_out
) {

    // hls-fpga-machine-learning insert IO
    #pragma HLS INTERFACE axis port=input_1,layer57_out 
    #pragma HLS DATAFLOW

    // hls-fpga-machine-learning insert load weights
#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        nnet::load_weights_from_txt<weight2_t, 972>(w2, "w2.txt");
        nnet::load_weights_from_txt<bias2_t, 36>(b2, "b2.txt");
        nnet::load_weights_from_txt<weight5_t, 11664>(w5, "w5.txt");
        nnet::load_weights_from_txt<bias5_t, 36>(b5, "b5.txt");
        nnet::load_weights_from_txt<weight7_t, 108>(w7, "w7.txt");
        nnet::load_weights_from_txt<bias7_t, 36>(b7, "b7.txt");
        nnet::load_weights_from_txt<weight11_t, 11664>(w11, "w11.txt");
        nnet::load_weights_from_txt<bias11_t, 36>(b11, "b11.txt");
        nnet::load_weights_from_txt<weight14_t, 15552>(w14, "w14.txt");
        nnet::load_weights_from_txt<bias14_t, 48>(b14, "b14.txt");
        nnet::load_weights_from_txt<weight17_t, 20736>(w17, "w17.txt");
        nnet::load_weights_from_txt<bias17_t, 48>(b17, "b17.txt");
        nnet::load_weights_from_txt<weight19_t, 1728>(w19, "w19.txt");
        nnet::load_weights_from_txt<bias19_t, 48>(b19, "b19.txt");
        nnet::load_weights_from_txt<weight23_t, 20736>(w23, "w23.txt");
        nnet::load_weights_from_txt<bias23_t, 48>(b23, "b23.txt");
        nnet::load_weights_from_txt<weight26_t, 25920>(w26, "w26.txt");
        nnet::load_weights_from_txt<bias26_t, 60>(b26, "b26.txt");
        nnet::load_weights_from_txt<weight29_t, 32400>(w29, "w29.txt");
        nnet::load_weights_from_txt<bias29_t, 60>(b29, "b29.txt");
        nnet::load_weights_from_txt<weight31_t, 2880>(w31, "w31.txt");
        nnet::load_weights_from_txt<bias31_t, 60>(b31, "b31.txt");
        nnet::load_weights_from_txt<weight37_t, 46656>(w37, "w37.txt");
        nnet::load_weights_from_txt<bias37_t, 48>(b37, "b37.txt");
        nnet::load_weights_from_txt<weight40_t, 20736>(w40, "w40.txt");
        nnet::load_weights_from_txt<bias40_t, 48>(b40, "b40.txt");
        nnet::load_weights_from_txt<weight42_t, 5184>(w42, "w42.txt");
        nnet::load_weights_from_txt<bias42_t, 48>(b42, "b42.txt");
        nnet::load_weights_from_txt<weight48_t, 27216>(w48, "w48.txt");
        nnet::load_weights_from_txt<bias48_t, 36>(b48, "b48.txt");
        nnet::load_weights_from_txt<weight51_t, 11664>(w51, "w51.txt");
        nnet::load_weights_from_txt<bias51_t, 36>(b51, "b51.txt");
        nnet::load_weights_from_txt<weight53_t, 3024>(w53, "w53.txt");
        nnet::load_weights_from_txt<bias53_t, 36>(b53, "b53.txt");
        nnet::load_weights_from_txt<weight57_t, 720>(w57, "w57.txt");
        nnet::load_weights_from_txt<bias57_t, 20>(b57, "b57.txt");
        loaded_weights = true;    }
#endif
    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************

    // hls-fpga-machine-learning insert layers

    hls::stream<input_t> layer59_cpy1("layer59_cpy1");
    #pragma HLS STREAM variable=layer59_cpy1 depth=2048 //4096
    hls::stream<input_t> layer59_cpy2("layer59_cpy2");
    #pragma HLS STREAM variable=layer59_cpy2 depth=2048 //4096
    nnet::clone_stream<input_t, input_t, 12288>(input_1, layer59_cpy1, layer59_cpy2); // clone_input_1

    hls::stream<layer66_t> layer66_out("layer66_out");
    #pragma HLS STREAM variable=layer66_out depth=2178 //4356
    nnet::zeropad2d_cl<input_t, layer66_t, config66>(layer59_cpy1, layer66_out); // zp2d_q_conv2d_batchnorm

    hls::stream<q_conv2d_batchnorm_result_t> layer2_out("layer2_out");
    #pragma HLS STREAM variable=layer2_out depth=2048 //4096
    nnet::conv_2d_cl<layer66_t, q_conv2d_batchnorm_result_t, config2>(layer66_out, layer2_out, w2, b2); // q_conv2d_batchnorm

    hls::stream<layer4_t> layer4_out("layer4_out");
    #pragma HLS STREAM variable=layer4_out depth=2048 //4096
    nnet::relu<q_conv2d_batchnorm_result_t, layer4_t, relu_config4>(layer2_out, layer4_out); // q_activation

    hls::stream<layer67_t> layer67_out("layer67_out");
    #pragma HLS STREAM variable=layer67_out depth=2178 //4356
    nnet::zeropad2d_cl<layer4_t, layer67_t, config67>(layer4_out, layer67_out); // zp2d_q_conv2d_batchnorm_1

    hls::stream<q_conv2d_batchnorm_1_result_t> layer5_out("layer5_out");
    #pragma HLS STREAM variable=layer5_out depth=2048 //4096
    nnet::conv_2d_cl<layer67_t, q_conv2d_batchnorm_1_result_t, config5>(layer67_out, layer5_out, w5, b5); // q_conv2d_batchnorm_1

    hls::stream<q_conv2d_result_t> layer7_out("layer7_out");
    #pragma HLS STREAM variable=layer7_out depth=2048 //4096
    nnet::pointwise_conv_2d_cl<input_t, q_conv2d_result_t, config78>(layer59_cpy2, layer7_out, w7, b7); // q_conv2d

    hls::stream<layer9_t> layer9_out("layer9_out");
    #pragma HLS STREAM variable=layer9_out depth=2048 //4096
    nnet::relu<q_conv2d_batchnorm_1_result_t, layer9_t, relu_config9>(layer5_out, layer9_out); // q_activation_1

    hls::stream<add_result_t> layer10_out("layer10_out");
    #pragma HLS STREAM variable=layer10_out depth=2048 //4096
    nnet::add<q_conv2d_result_t, layer9_t, add_result_t, config10>(layer7_out, layer9_out, layer10_out); // add

    hls::stream<add_result_t> layer60_cpy1("layer60_cpy1");
    #pragma HLS STREAM variable=layer60_cpy1 depth=2048 //4096
    hls::stream<add_result_t> layer60_cpy2("layer60_cpy2");
    #pragma HLS STREAM variable=layer60_cpy2 depth=2048 //4096
    nnet::clone_stream<add_result_t, add_result_t, 147456>(layer10_out, layer60_cpy1, layer60_cpy2); // clone_add

    hls::stream<layer68_t> layer68_out("layer68_out");
    #pragma HLS STREAM variable=layer68_out depth=2112 //4225
    nnet::zeropad2d_cl<add_result_t, layer68_t, config68>(layer60_cpy1, layer68_out); // zp2d_q_conv2d_batchnorm_2

    hls::stream<q_conv2d_batchnorm_2_result_t> layer11_out("layer11_out");
    #pragma HLS STREAM variable=layer11_out depth=512 //1024
    nnet::conv_2d_cl<layer68_t, q_conv2d_batchnorm_2_result_t, config11>(layer68_out, layer11_out, w11, b11); // q_conv2d_batchnorm_2

    hls::stream<layer13_t> layer13_out("layer13_out");
    #pragma HLS STREAM variable=layer13_out depth=512 //1024
    nnet::relu<q_conv2d_batchnorm_2_result_t, layer13_t, relu_config13>(layer11_out, layer13_out); // q_activation_2

    hls::stream<layer13_t> layer61_cpy1("layer61_cpy1");
    #pragma HLS STREAM variable=layer61_cpy1 depth=512 //1024
    hls::stream<layer13_t> layer61_cpy2("layer61_cpy2");
    #pragma HLS STREAM variable=layer61_cpy2 depth=512 //1024
    nnet::clone_stream<layer13_t, layer13_t, 36864>(layer13_out, layer61_cpy1, layer61_cpy2); // clone_q_activation_2

    hls::stream<layer69_t> layer69_out("layer69_out");
    #pragma HLS STREAM variable=layer69_out depth=578 //1156
    nnet::zeropad2d_cl<layer13_t, layer69_t, config69>(layer61_cpy1, layer69_out); // zp2d_q_conv2d_batchnorm_3

    hls::stream<q_conv2d_batchnorm_3_result_t> layer14_out("layer14_out");
    #pragma HLS STREAM variable=layer14_out depth=512 //1024
    nnet::conv_2d_cl<layer69_t, q_conv2d_batchnorm_3_result_t, config14>(layer69_out, layer14_out, w14, b14); // q_conv2d_batchnorm_3

    hls::stream<layer16_t> layer16_out("layer16_out");
    #pragma HLS STREAM variable=layer16_out depth=512 //1024
    nnet::relu<q_conv2d_batchnorm_3_result_t, layer16_t, relu_config16>(layer14_out, layer16_out); // q_activation_3

    hls::stream<layer70_t> layer70_out("layer70_out");
    #pragma HLS STREAM variable=layer70_out depth=578 //1156
    nnet::zeropad2d_cl<layer16_t, layer70_t, config70>(layer16_out, layer70_out); // zp2d_q_conv2d_batchnorm_4

    hls::stream<q_conv2d_batchnorm_4_result_t> layer17_out("layer17_out");
    #pragma HLS STREAM variable=layer17_out depth=512 //1024
    nnet::conv_2d_cl<layer70_t, q_conv2d_batchnorm_4_result_t, config17>(layer70_out, layer17_out, w17, b17); // q_conv2d_batchnorm_4

    hls::stream<q_conv2d_1_result_t> layer19_out("layer19_out");
    #pragma HLS STREAM variable=layer19_out depth=512 //1024
    nnet::pointwise_conv_2d_cl<layer13_t, q_conv2d_1_result_t, config79>(layer61_cpy2, layer19_out, w19, b19); // q_conv2d_1

    hls::stream<layer21_t> layer21_out("layer21_out");
    #pragma HLS STREAM variable=layer21_out depth=512 //1024
    nnet::relu<q_conv2d_batchnorm_4_result_t, layer21_t, relu_config21>(layer17_out, layer21_out); // q_activation_4

    hls::stream<add_1_result_t> layer22_out("layer22_out");
    #pragma HLS STREAM variable=layer22_out depth=512 //1024
    nnet::add<q_conv2d_1_result_t, layer21_t, add_1_result_t, config22>(layer19_out, layer21_out, layer22_out); // add_1

    hls::stream<add_1_result_t> layer62_cpy1("layer62_cpy1");
    #pragma HLS STREAM variable=layer62_cpy1 depth=512 //1024
    hls::stream<add_1_result_t> layer62_cpy2("layer62_cpy2");
    #pragma HLS STREAM variable=layer62_cpy2 depth=512 //1024
    nnet::clone_stream<add_1_result_t, add_1_result_t, 49152>(layer22_out, layer62_cpy1, layer62_cpy2); // clone_add_1

    hls::stream<layer71_t> layer71_out("layer71_out");
    #pragma HLS STREAM variable=layer71_out depth=544 //1089
    nnet::zeropad2d_cl<add_1_result_t, layer71_t, config71>(layer62_cpy1, layer71_out); // zp2d_q_conv2d_batchnorm_5

    hls::stream<q_conv2d_batchnorm_5_result_t> layer23_out("layer23_out");
    #pragma HLS STREAM variable=layer23_out depth=128 //256
    nnet::conv_2d_cl<layer71_t, q_conv2d_batchnorm_5_result_t, config23>(layer71_out, layer23_out, w23, b23); // q_conv2d_batchnorm_5

    hls::stream<layer25_t> layer25_out("layer25_out");
    #pragma HLS STREAM variable=layer25_out depth=128 //256
    nnet::relu<q_conv2d_batchnorm_5_result_t, layer25_t, relu_config25>(layer23_out, layer25_out); // q_activation_5

    hls::stream<layer25_t> layer63_cpy1("layer63_cpy1");
    #pragma HLS STREAM variable=layer63_cpy1 depth=128 //256
    hls::stream<layer25_t> layer63_cpy2("layer63_cpy2");
    #pragma HLS STREAM variable=layer63_cpy2 depth=128 //256
    nnet::clone_stream<layer25_t, layer25_t, 12288>(layer25_out, layer63_cpy1, layer63_cpy2); // clone_q_activation_5

    hls::stream<layer72_t> layer72_out("layer72_out");
    #pragma HLS STREAM variable=layer72_out depth=162 //324
    nnet::zeropad2d_cl<layer25_t, layer72_t, config72>(layer63_cpy1, layer72_out); // zp2d_q_conv2d_batchnorm_6

    hls::stream<q_conv2d_batchnorm_6_result_t> layer26_out("layer26_out");
    #pragma HLS STREAM variable=layer26_out depth=128 //256
    nnet::conv_2d_cl<layer72_t, q_conv2d_batchnorm_6_result_t, config26>(layer72_out, layer26_out, w26, b26); // q_conv2d_batchnorm_6

    hls::stream<layer28_t> layer28_out("layer28_out");
    #pragma HLS STREAM variable=layer28_out depth=128 //256
    nnet::relu<q_conv2d_batchnorm_6_result_t, layer28_t, relu_config28>(layer26_out, layer28_out); // q_activation_6

    hls::stream<layer73_t> layer73_out("layer73_out");
    #pragma HLS STREAM variable=layer73_out depth=162 //324
    nnet::zeropad2d_cl<layer28_t, layer73_t, config73>(layer28_out, layer73_out); // zp2d_q_conv2d_batchnorm_7

    hls::stream<q_conv2d_batchnorm_7_result_t> layer29_out("layer29_out");
    #pragma HLS STREAM variable=layer29_out depth=128 //256
    nnet::conv_2d_cl<layer73_t, q_conv2d_batchnorm_7_result_t, config29>(layer73_out, layer29_out, w29, b29); // q_conv2d_batchnorm_7

    hls::stream<q_conv2d_2_result_t> layer31_out("layer31_out");
    #pragma HLS STREAM variable=layer31_out depth=128 //256
    nnet::pointwise_conv_2d_cl<layer25_t, q_conv2d_2_result_t, config80>(layer63_cpy2, layer31_out, w31, b31); // q_conv2d_2

    hls::stream<layer33_t> layer33_out("layer33_out");
    #pragma HLS STREAM variable=layer33_out depth=128 //256
    nnet::relu<q_conv2d_batchnorm_7_result_t, layer33_t, relu_config33>(layer29_out, layer33_out); // q_activation_7

    hls::stream<add_2_result_t> layer34_out("layer34_out");
    #pragma HLS STREAM variable=layer34_out depth=128 //256
    nnet::add<q_conv2d_2_result_t, layer33_t, add_2_result_t, config34>(layer31_out, layer33_out, layer34_out); // add_2

    hls::stream<layer35_t> layer35_out("layer35_out");
    #pragma HLS STREAM variable=layer35_out depth=512 //1024
    nnet::resize_nearest<add_2_result_t, config35>(layer34_out, layer35_out); // up_sampling2d

    hls::stream<concatenate_result_t> layer36_out("layer36_out");
    #pragma HLS STREAM variable=layer36_out depth=512 //1024
    nnet::concatenate3d<layer35_t, add_1_result_t, concatenate_result_t, config36>(layer35_out, layer62_cpy2, layer36_out); // concatenate

    hls::stream<concatenate_result_t> layer64_cpy1("layer64_cpy1");
    #pragma HLS STREAM variable=layer64_cpy1 depth=512 //1024
    hls::stream<concatenate_result_t> layer64_cpy2("layer64_cpy2");
    #pragma HLS STREAM variable=layer64_cpy2 depth=512 //1024
    nnet::clone_stream<concatenate_result_t, concatenate_result_t, 110592>(layer36_out, layer64_cpy1, layer64_cpy2); // clone_concatenate

    hls::stream<layer74_t> layer74_out("layer74_out");
    #pragma HLS STREAM variable=layer74_out depth=578 //1156
    nnet::zeropad2d_cl<concatenate_result_t, layer74_t, config74>(layer64_cpy1, layer74_out); // zp2d_q_conv2d_batchnorm_8

    hls::stream<q_conv2d_batchnorm_8_result_t> layer37_out("layer37_out");
    #pragma HLS STREAM variable=layer37_out depth=512 //1024
    nnet::conv_2d_cl<layer74_t, q_conv2d_batchnorm_8_result_t, config37>(layer74_out, layer37_out, w37, b37); // q_conv2d_batchnorm_8

    hls::stream<layer39_t> layer39_out("layer39_out");
    #pragma HLS STREAM variable=layer39_out depth=512 //1024
    nnet::relu<q_conv2d_batchnorm_8_result_t, layer39_t, relu_config39>(layer37_out, layer39_out); // q_activation_8

    hls::stream<layer75_t> layer75_out("layer75_out");
    #pragma HLS STREAM variable=layer75_out depth=578 //1156
    nnet::zeropad2d_cl<layer39_t, layer75_t, config75>(layer39_out, layer75_out); // zp2d_q_conv2d_batchnorm_9

    hls::stream<q_conv2d_batchnorm_9_result_t> layer40_out("layer40_out");
    #pragma HLS STREAM variable=layer40_out depth=512 //1024
    nnet::conv_2d_cl<layer75_t, q_conv2d_batchnorm_9_result_t, config40>(layer75_out, layer40_out, w40, b40); // q_conv2d_batchnorm_9

    hls::stream<q_conv2d_3_result_t> layer42_out("layer42_out");
    #pragma HLS STREAM variable=layer42_out depth=512 //1024
    nnet::pointwise_conv_2d_cl<concatenate_result_t, q_conv2d_3_result_t, config81>(layer64_cpy2, layer42_out, w42, b42); // q_conv2d_3

    hls::stream<layer44_t> layer44_out("layer44_out");
    #pragma HLS STREAM variable=layer44_out depth=512 //1024
    nnet::relu<q_conv2d_batchnorm_9_result_t, layer44_t, relu_config44>(layer40_out, layer44_out); // q_activation_9

    hls::stream<add_3_result_t> layer45_out("layer45_out");
    #pragma HLS STREAM variable=layer45_out depth=512 //1024
    nnet::add<q_conv2d_3_result_t, layer44_t, add_3_result_t, config45>(layer42_out, layer44_out, layer45_out); // add_3

    hls::stream<layer46_t> layer46_out("layer46_out");
    #pragma HLS STREAM variable=layer46_out depth=2048 //4096
    nnet::resize_nearest<add_3_result_t, config46>(layer45_out, layer46_out); // up_sampling2d_1

    hls::stream<concatenate_1_result_t> layer47_out("layer47_out");
    #pragma HLS STREAM variable=layer47_out depth=2048 //4096
    nnet::concatenate3d<layer46_t, add_result_t, concatenate_1_result_t, config47>(layer46_out, layer60_cpy2, layer47_out); // concatenate_1

    hls::stream<concatenate_1_result_t> layer65_cpy1("layer65_cpy1");
    #pragma HLS STREAM variable=layer65_cpy1 depth=2048 //4096
    hls::stream<concatenate_1_result_t> layer65_cpy2("layer65_cpy2");
    #pragma HLS STREAM variable=layer65_cpy2 depth=2048 //4096
    nnet::clone_stream<concatenate_1_result_t, concatenate_1_result_t, 344064>(layer47_out, layer65_cpy1, layer65_cpy2); // clone_concatenate_1

    hls::stream<layer76_t> layer76_out("layer76_out");
    #pragma HLS STREAM variable=layer76_out depth=2178 //4356
    nnet::zeropad2d_cl<concatenate_1_result_t, layer76_t, config76>(layer65_cpy1, layer76_out); // zp2d_q_conv2d_batchnorm_10

    hls::stream<q_conv2d_batchnorm_10_result_t> layer48_out("layer48_out");
    #pragma HLS STREAM variable=layer48_out depth=2048 //4096
    nnet::conv_2d_cl<layer76_t, q_conv2d_batchnorm_10_result_t, config48>(layer76_out, layer48_out, w48, b48); // q_conv2d_batchnorm_10

    hls::stream<layer50_t> layer50_out("layer50_out");
    #pragma HLS STREAM variable=layer50_out depth=2048 //4096
    nnet::relu<q_conv2d_batchnorm_10_result_t, layer50_t, relu_config50>(layer48_out, layer50_out); // q_activation_10

    hls::stream<layer77_t> layer77_out("layer77_out");
    #pragma HLS STREAM variable=layer77_out depth=2178 //4356
    nnet::zeropad2d_cl<layer50_t, layer77_t, config77>(layer50_out, layer77_out); // zp2d_q_conv2d_batchnorm_11

    hls::stream<q_conv2d_batchnorm_11_result_t> layer51_out("layer51_out");
    #pragma HLS STREAM variable=layer51_out depth=2048 //4096
    nnet::conv_2d_cl<layer77_t, q_conv2d_batchnorm_11_result_t, config51>(layer77_out, layer51_out, w51, b51); // q_conv2d_batchnorm_11

    hls::stream<q_conv2d_4_result_t> layer53_out("layer53_out");
    #pragma HLS STREAM variable=layer53_out depth=2048 //4096
    nnet::pointwise_conv_2d_cl<concatenate_1_result_t, q_conv2d_4_result_t, config82>(layer65_cpy2, layer53_out, w53, b53); // q_conv2d_4

    hls::stream<layer55_t> layer55_out("layer55_out");
    #pragma HLS STREAM variable=layer55_out depth=2048 //4096
    nnet::relu<q_conv2d_batchnorm_11_result_t, layer55_t, relu_config55>(layer51_out, layer55_out); // q_activation_11

    hls::stream<add_4_result_t> layer56_out("layer56_out");
    #pragma HLS STREAM variable=layer56_out depth=2048 //4096
    nnet::add<q_conv2d_4_result_t, layer55_t, add_4_result_t, config56>(layer53_out, layer55_out, layer56_out); // add_4

    nnet::pointwise_conv_2d_cl<add_4_result_t, result_t, config83>(layer56_out, layer57_out, w57, b57); // q_conv2d_5

}

