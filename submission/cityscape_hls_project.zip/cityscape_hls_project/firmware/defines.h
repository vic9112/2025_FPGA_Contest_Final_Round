#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <cstddef>
#include <cstdio>

// hls-fpga-machine-learning insert numbers
#define N_INPUT_1_1 64
#define N_INPUT_2_1 64
#define N_INPUT_3_1 3
#define N_INPUT_1_1 64
#define N_INPUT_2_1 64
#define N_INPUT_3_1 3
#define OUT_HEIGHT_66 66
#define OUT_WIDTH_66 66
#define N_CHAN_66 3
#define OUT_HEIGHT_2 64
#define OUT_WIDTH_2 64
#define N_FILT_2 36
#define OUT_HEIGHT_2 64
#define OUT_WIDTH_2 64
#define N_FILT_2 36
#define OUT_HEIGHT_67 66
#define OUT_WIDTH_67 66
#define N_CHAN_67 36
#define OUT_HEIGHT_5 64
#define OUT_WIDTH_5 64
#define N_FILT_5 36
#define OUT_HEIGHT_7 64
#define OUT_WIDTH_7 64
#define N_FILT_7 36
#define OUT_HEIGHT_5 64
#define OUT_WIDTH_5 64
#define N_FILT_5 36
#define OUT_HEIGHT_7 64
#define OUT_WIDTH_7 64
#define N_FILT_7 36
#define OUT_HEIGHT_7 64
#define OUT_WIDTH_7 64
#define N_FILT_7 36
#define OUT_HEIGHT_68 65
#define OUT_WIDTH_68 65
#define N_CHAN_68 36
#define OUT_HEIGHT_11 32
#define OUT_WIDTH_11 32
#define N_FILT_11 36
#define OUT_HEIGHT_11 32
#define OUT_WIDTH_11 32
#define N_FILT_11 36
#define OUT_HEIGHT_11 32
#define OUT_WIDTH_11 32
#define N_FILT_11 36
#define OUT_HEIGHT_69 34
#define OUT_WIDTH_69 34
#define N_CHAN_69 36
#define OUT_HEIGHT_14 32
#define OUT_WIDTH_14 32
#define N_FILT_14 48
#define OUT_HEIGHT_14 32
#define OUT_WIDTH_14 32
#define N_FILT_14 48
#define OUT_HEIGHT_70 34
#define OUT_WIDTH_70 34
#define N_CHAN_70 48
#define OUT_HEIGHT_17 32
#define OUT_WIDTH_17 32
#define N_FILT_17 48
#define OUT_HEIGHT_19 32
#define OUT_WIDTH_19 32
#define N_FILT_19 48
#define OUT_HEIGHT_17 32
#define OUT_WIDTH_17 32
#define N_FILT_17 48
#define OUT_HEIGHT_19 32
#define OUT_WIDTH_19 32
#define N_FILT_19 48
#define OUT_HEIGHT_19 32
#define OUT_WIDTH_19 32
#define N_FILT_19 48
#define OUT_HEIGHT_71 33
#define OUT_WIDTH_71 33
#define N_CHAN_71 48
#define OUT_HEIGHT_23 16
#define OUT_WIDTH_23 16
#define N_FILT_23 48
#define OUT_HEIGHT_23 16
#define OUT_WIDTH_23 16
#define N_FILT_23 48
#define OUT_HEIGHT_23 16
#define OUT_WIDTH_23 16
#define N_FILT_23 48
#define OUT_HEIGHT_72 18
#define OUT_WIDTH_72 18
#define N_CHAN_72 48
#define OUT_HEIGHT_26 16
#define OUT_WIDTH_26 16
#define N_FILT_26 60
#define OUT_HEIGHT_26 16
#define OUT_WIDTH_26 16
#define N_FILT_26 60
#define OUT_HEIGHT_73 18
#define OUT_WIDTH_73 18
#define N_CHAN_73 60
#define OUT_HEIGHT_29 16
#define OUT_WIDTH_29 16
#define N_FILT_29 60
#define OUT_HEIGHT_31 16
#define OUT_WIDTH_31 16
#define N_FILT_31 60
#define OUT_HEIGHT_29 16
#define OUT_WIDTH_29 16
#define N_FILT_29 60
#define OUT_HEIGHT_31 16
#define OUT_WIDTH_31 16
#define N_FILT_31 60
#define OUT_HEIGHT_35 32
#define OUT_WIDTH_35 32
#define N_CHAN_35 60
#define OUT_CONCAT_0_36 32
#define OUT_CONCAT_1_36 32
#define OUT_CONCAT_2_36 108
#define OUT_CONCAT_0_36 32
#define OUT_CONCAT_1_36 32
#define OUT_CONCAT_2_36 108
#define OUT_HEIGHT_74 34
#define OUT_WIDTH_74 34
#define N_CHAN_74 108
#define OUT_HEIGHT_37 32
#define OUT_WIDTH_37 32
#define N_FILT_37 48
#define OUT_HEIGHT_37 32
#define OUT_WIDTH_37 32
#define N_FILT_37 48
#define OUT_HEIGHT_75 34
#define OUT_WIDTH_75 34
#define N_CHAN_75 48
#define OUT_HEIGHT_40 32
#define OUT_WIDTH_40 32
#define N_FILT_40 48
#define OUT_HEIGHT_42 32
#define OUT_WIDTH_42 32
#define N_FILT_42 48
#define OUT_HEIGHT_40 32
#define OUT_WIDTH_40 32
#define N_FILT_40 48
#define OUT_HEIGHT_42 32
#define OUT_WIDTH_42 32
#define N_FILT_42 48
#define OUT_HEIGHT_46 64
#define OUT_WIDTH_46 64
#define N_CHAN_46 48
#define OUT_CONCAT_0_47 64
#define OUT_CONCAT_1_47 64
#define OUT_CONCAT_2_47 84
#define OUT_CONCAT_0_47 64
#define OUT_CONCAT_1_47 64
#define OUT_CONCAT_2_47 84
#define OUT_HEIGHT_76 66
#define OUT_WIDTH_76 66
#define N_CHAN_76 84
#define OUT_HEIGHT_48 64
#define OUT_WIDTH_48 64
#define N_FILT_48 36
#define OUT_HEIGHT_48 64
#define OUT_WIDTH_48 64
#define N_FILT_48 36
#define OUT_HEIGHT_77 66
#define OUT_WIDTH_77 66
#define N_CHAN_77 36
#define OUT_HEIGHT_51 64
#define OUT_WIDTH_51 64
#define N_FILT_51 36
#define OUT_HEIGHT_53 64
#define OUT_WIDTH_53 64
#define N_FILT_53 36
#define OUT_HEIGHT_51 64
#define OUT_WIDTH_51 64
#define N_FILT_51 36
#define OUT_HEIGHT_53 64
#define OUT_WIDTH_53 64
#define N_FILT_53 36
#define OUT_HEIGHT_57 64
#define OUT_WIDTH_57 64
#define N_FILT_57 20


// hls-fpga-machine-learning insert layer-precision
typedef nnet::array<ap_fixed<32,16>, 3*1> input_t;
typedef nnet::array<ap_fixed<32,16>, 3*1> layer66_t;
typedef ap_fixed<46,25> q_conv2d_batchnorm_accum_t;
typedef nnet::array<ap_fixed<46,25>, 36*1> q_conv2d_batchnorm_result_t;
typedef ap_fixed<8,3> weight2_t;
typedef ap_fixed<8,3> bias2_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 36*1> layer4_t;
typedef ap_fixed<18,8> q_activation_table_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 36*1> layer67_t;
typedef ap_fixed<24,13> q_conv2d_batchnorm_1_accum_t;
typedef nnet::array<ap_fixed<24,13>, 36*1> q_conv2d_batchnorm_1_result_t;
typedef ap_fixed<8,3> weight5_t;
typedef ap_fixed<8,3> bias5_t;
typedef ap_fixed<43,22> q_conv2d_accum_t;
typedef nnet::array<ap_fixed<43,22>, 36*1> q_conv2d_result_t;
typedef ap_fixed<8,3> weight7_t;
typedef ap_uint<1> bias7_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 36*1> layer9_t;
typedef ap_fixed<18,8> q_activation_1_table_t;
typedef nnet::array<ap_fixed<44,23>, 36*1> add_result_t;
typedef nnet::array<ap_fixed<44,23>, 36*1> layer68_t;
typedef ap_fixed<62,36> q_conv2d_batchnorm_2_accum_t;
typedef nnet::array<ap_fixed<62,36>, 36*1> q_conv2d_batchnorm_2_result_t;
typedef ap_fixed<8,3> weight11_t;
typedef ap_fixed<8,3> bias11_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 36*1> layer13_t;
typedef ap_fixed<18,8> q_activation_2_table_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 36*1> layer69_t;
typedef ap_fixed<24,13> q_conv2d_batchnorm_3_accum_t;
typedef nnet::array<ap_fixed<24,13>, 48*1> q_conv2d_batchnorm_3_result_t;
typedef ap_fixed<8,3> weight14_t;
typedef ap_fixed<8,3> bias14_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 48*1> layer16_t;
typedef ap_fixed<18,8> q_activation_3_table_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 48*1> layer70_t;
typedef ap_fixed<24,13> q_conv2d_batchnorm_4_accum_t;
typedef nnet::array<ap_fixed<24,13>, 48*1> q_conv2d_batchnorm_4_result_t;
typedef ap_fixed<8,3> weight17_t;
typedef ap_fixed<8,3> bias17_t;
typedef ap_fixed<21,10> q_conv2d_1_accum_t;
typedef nnet::array<ap_fixed<21,10>, 48*1> q_conv2d_1_result_t;
typedef ap_fixed<8,3> weight19_t;
typedef ap_uint<1> bias19_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 48*1> layer21_t;
typedef ap_fixed<18,8> q_activation_4_table_t;
typedef nnet::array<ap_fixed<22,11>, 48*1> add_1_result_t;
typedef nnet::array<ap_fixed<22,11>, 48*1> layer71_t;
typedef ap_fixed<40,24> q_conv2d_batchnorm_5_accum_t;
typedef nnet::array<ap_fixed<40,24>, 48*1> q_conv2d_batchnorm_5_result_t;
typedef ap_fixed<8,3> weight23_t;
typedef ap_fixed<8,3> bias23_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 48*1> layer25_t;
typedef ap_fixed<18,8> q_activation_5_table_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 48*1> layer72_t;
typedef ap_fixed<24,13> q_conv2d_batchnorm_6_accum_t;
typedef nnet::array<ap_fixed<24,13>, 60*1> q_conv2d_batchnorm_6_result_t;
typedef ap_fixed<8,3> weight26_t;
typedef ap_fixed<8,3> bias26_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 60*1> layer28_t;
typedef ap_fixed<18,8> q_activation_6_table_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 60*1> layer73_t;
typedef ap_fixed<25,14> q_conv2d_batchnorm_7_accum_t;
typedef nnet::array<ap_fixed<25,14>, 60*1> q_conv2d_batchnorm_7_result_t;
typedef ap_fixed<8,3> weight29_t;
typedef ap_fixed<8,3> bias29_t;
typedef ap_fixed<21,10> q_conv2d_2_accum_t;
typedef nnet::array<ap_fixed<21,10>, 60*1> q_conv2d_2_result_t;
typedef ap_fixed<8,3> weight31_t;
typedef ap_uint<1> bias31_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 60*1> layer33_t;
typedef ap_fixed<18,8> q_activation_7_table_t;
typedef nnet::array<ap_fixed<22,11>, 60*1> add_2_result_t;
typedef nnet::array<ap_fixed<22,11>, 60*1> layer35_t;
typedef nnet::array<ap_fixed<22,11>, 108*1> concatenate_result_t;
typedef nnet::array<ap_fixed<22,11>, 108*1> layer74_t;
typedef ap_fixed<41,25> q_conv2d_batchnorm_8_accum_t;
typedef nnet::array<ap_fixed<41,25>, 48*1> q_conv2d_batchnorm_8_result_t;
typedef ap_fixed<8,3> weight37_t;
typedef ap_fixed<8,3> bias37_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 48*1> layer39_t;
typedef ap_fixed<18,8> q_activation_8_table_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 48*1> layer75_t;
typedef ap_fixed<24,13> q_conv2d_batchnorm_9_accum_t;
typedef nnet::array<ap_fixed<24,13>, 48*1> q_conv2d_batchnorm_9_result_t;
typedef ap_fixed<8,3> weight40_t;
typedef ap_fixed<8,3> bias40_t;
typedef ap_fixed<38,22> q_conv2d_3_accum_t;
typedef nnet::array<ap_fixed<38,22>, 48*1> q_conv2d_3_result_t;
typedef ap_fixed<8,3> weight42_t;
typedef ap_uint<1> bias42_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 48*1> layer44_t;
typedef ap_fixed<18,8> q_activation_9_table_t;
typedef nnet::array<ap_fixed<39,23>, 48*1> add_3_result_t;
typedef nnet::array<ap_fixed<39,23>, 48*1> layer46_t;
typedef nnet::array<ap_fixed<44,23>, 84*1> concatenate_1_result_t;
typedef nnet::array<ap_fixed<44,23>, 84*1> layer76_t;
typedef ap_fixed<63,37> q_conv2d_batchnorm_10_accum_t;
typedef nnet::array<ap_fixed<63,37>, 36*1> q_conv2d_batchnorm_10_result_t;
typedef ap_fixed<8,3> weight48_t;
typedef ap_fixed<8,3> bias48_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 36*1> layer50_t;
typedef ap_fixed<18,8> q_activation_10_table_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 36*1> layer77_t;
typedef ap_fixed<24,13> q_conv2d_batchnorm_11_accum_t;
typedef nnet::array<ap_fixed<24,13>, 36*1> q_conv2d_batchnorm_11_result_t;
typedef ap_fixed<8,3> weight51_t;
typedef ap_fixed<8,3> bias51_t;
typedef ap_fixed<60,34> q_conv2d_4_accum_t;
typedef nnet::array<ap_fixed<60,34>, 36*1> q_conv2d_4_result_t;
typedef ap_fixed<8,3> weight53_t;
typedef ap_uint<1> bias53_t;
typedef nnet::array<ap_ufixed<6,0,AP_RND_CONV,AP_SAT,0>, 36*1> layer55_t;
typedef ap_fixed<18,8> q_activation_11_table_t;
typedef nnet::array<ap_fixed<61,35>, 36*1> add_4_result_t;
typedef ap_fixed<76,45> q_conv2d_5_accum_t;
typedef nnet::array<ap_fixed<76,45>, 20*1> result_t;
typedef ap_fixed<8,3> weight57_t;
typedef ap_fixed<8,3> bias57_t;


#endif
